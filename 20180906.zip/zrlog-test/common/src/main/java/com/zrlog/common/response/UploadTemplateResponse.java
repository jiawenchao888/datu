package com.zrlog.common.response;

public class UploadTemplateResponse extends StandardResponse {

}
