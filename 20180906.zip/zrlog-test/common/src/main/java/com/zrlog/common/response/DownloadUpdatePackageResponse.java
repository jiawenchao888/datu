package com.zrlog.common.response;

public class DownloadUpdatePackageResponse extends StandardResponse {

    private int process;

    public int getProcess() {
        return process;
    }

    public void setProcess(int process) {
        this.process = process;
    }
}
