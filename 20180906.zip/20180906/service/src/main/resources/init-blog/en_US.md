> Hello World means "world, hello". Because it was used as the first demo program in "The C Programme Language", it was very famous, so later programmers continued this habit while learning programming or debugging equipment.

ZrLog is a blog/CMS program developed using Java. It is characterized by simplicity, ease of use, componentization, and low memory usage. Comes with the Markdown editor, allowing more focus on writing, rather than spending a lot of time learning the use of the program

Now you can edit or delete this article by visiting [admin](${basePath}/admin/index?id=1#article_edit) and start writing happily.